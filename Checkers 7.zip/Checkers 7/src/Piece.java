import javax.swing.*;
import java.awt.*;

public class Piece extends JLabel {
    String side = "";
    ImageIcon pieceRed = new ImageIcon("checkerPieceRed.png");
    ImageIcon pieceBlack = new ImageIcon("checkerPieceBlack.png");



    public String getSide() {
		return this.side;
	}
    public void setSide(String side)
    {
		this.side = side;
	}

    public void setBLACK(){
        setIcon(pieceBlack);
        repaint();

        // Set the size of the JLabel to match the size of the image
        setPreferredSize(new Dimension(pieceBlack.getIconWidth(), pieceBlack.getIconHeight()-50));

    }

    public void setRED(){
        setIcon(pieceRed);
        repaint();
        // Set the size of the JLabel to match the size of the image
        setPreferredSize(new Dimension(pieceRed.getIconWidth(), pieceRed.getIconHeight()-50));

    }

    public Piece(String side) {
       

        this.side = side;

    }
}