import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Board 
{

   // https://www.tabnine.com/code/java/class-index

    // Colors for the board
    private Color COLOR_1 = new Color(250, 250, 250);
    private Color COLOR_2 = new Color(0, 0, 0);
    private Color HIGHLIGHT_COLOR = new Color(255, 255, 0);

    // Array to hold buttons
    private JButton[][] buttons = new JButton[8][8];
    private boolean[][] pressedStates = new boolean[8][8];
  
    // Frame and panels
    private JFrame frame = new JFrame();
    private JPanel mainPanel = new JPanel(); // Main panel to hold everything
    private JPanel buttonPanel = new JPanel(); //centered on mainPanel, can be easily adjusted for size
    private JPanel textPanel = new JPanel();

    // Text field and button
    private JTextField text = new JTextField();
    private JButton backButton = new JButton();

    //turn counter
    int turnCounter = 3;

  

    public Board() 
    {
        initializeGUI();
        initializeButtons();
        addPieces();
        resetBoard();
        frame.setVisible(true);
    }


    private void initializeGUI()
    {
        //mac slay
        try
            {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            }
            catch(Exception e)
            {
                e.printStackTrace(); 
            }

        // JFrame setup
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        int screenWidth = 1000;
        int screenHeight = 900;

        // Set the frame size based on screen size
        frame.setSize(screenWidth, screenHeight);

        // Text setup
        text.setBackground(Color.BLACK);
        text.setForeground(Color.PINK);
        text.setFont(new Font("SERIF", Font.BOLD, 75));
        text.setHorizontalAlignment(JLabel.CENTER);
        text.setText("CHECKERS");
        text.setOpaque(true);
        text.setEditable(false);

        // Text panel setup
        textPanel.setLayout(new BorderLayout());
        textPanel.add(text);

         // Back button setup
         backButton.setText("Back");
         backButton.addActionListener(new ActionListener() 
         {
             @Override
             public void actionPerformed(ActionEvent e) 
             {
                 frame.dispose();
                 GUI.frame.setState(Frame.NORMAL);
             }
         });
         // Add components to frame
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(textPanel, BorderLayout.NORTH);
         // Button panel setup
         buttonPanel.setLayout(new GridLayout(8, 8));
         buttonPanel.setPreferredSize(new Dimension(550, 550));
         JPanel centerPanel = new JPanel(new GridBagLayout()); // Put the button panel on another JPanel, and then put THAT Jpanel on the main panel.
         centerPanel.add(buttonPanel);
          // Add centerPanel with buttonPanel to main panel
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        //add ack button to main panel
        mainPanel.add(backButton, BorderLayout.SOUTH);
        frame.setResizable(false);

          // Add main panel to frame
          frame.add(mainPanel);
          frame.setVisible(true);
    }

    // Initialize buttons and add to panel
   // Initialize buttons and add to panel
// Initialize buttons and add to panel
private void initializeButtons() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            final int row = i; // Final variables for action listener
            final int col = j;
            buttons[i][j] = new JButton();
            buttons[i][j].setFocusable(false);
            buttons[i][j].setOpaque(true);
            buttons[i][j].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {

                        highlightPossibleMoves(row, col); // Highlight cells
                        pressedStates[row][col] = true; // Mark the button as clicked
                    } catch (Exception ex) {
                        // Handle exceptions
                        ex.printStackTrace();
                    }
                }
            });
            buttonPanel.add(buttons[i][j]);
        }
    }
}

    public void addPieces()
    {
        for (int i = 0; i < 3; i++) 
        {
            for (int j = 0; j < 8; j++) 
            {
                if ((i + j) % 2 == 0) 
                {
                    Piece piece = new Piece("red"); //set side
                    piece.setRED(); //changes image to red checkers piece
                    buttons[i][j].setLayout(new FlowLayout(FlowLayout.CENTER)); //centers the image on the button
                    buttons[i][j].add(piece);
                }
            }
        }
        // Add black pieces to board
        for (int i = 5; i < 8; i++) 
        {
            for (int j = 0; j < 8; j++) 
            {
                if ((i + j) % 2 == 0) 
                {
                    Piece piece = new Piece("black"); //set side
                    piece.setBLACK(); //changes image to black checkers piece
                    buttons[i][j].setLayout(new FlowLayout(FlowLayout.CENTER)); //centers the image on the button
                    buttons[i][j].add(piece);
                }
            }
        }
    }
    

    // Highlight possible moves buttons
    /**
     * @param row The row of the button clicked
     * @param col The column of the button clicked
     */
    private void highlightPossibleMoves(int row, int col) 
    {
        System.out.println("Highlighting possible moves for button at [" + row + ", " + col + "]");
        // Reset the board to clear any previous highlights
        resetBoard();
    
         // Check if there's a piece present on the button
    if (buttons[row][col].getComponentCount() > 0) {
         // Get the color of the piece at the clicked position
        String pieceColor = ((Piece) buttons[row][col].getComponent(0)).getSide();
        
        int[] dx;
        int[] dy;

        // Define movement directions based on piece color
        if (pieceColor.equals("red")) 
        {
            // Red pieces move downwards
            dx = new int[]{1, 1};
            dy = new int[]{1, -1};
        } else 
        {
            // Black pieces move upwards
            dx = new int[]{-1, -1};
            dy = new int[]{-1, 1};
        }
    
         // Iterate over possible movement directions
        for (int i = 0; i < 2; i++) 
        {
            // Calculate new position and jump position
            int newRow = row + dx[i];
            int newCol = col + dy[i];
    
            //jump position
            int jumpRow = row + 2 * dx[i];
            int jumpCol = col + 2 * dy[i];
    
              // Check if new position is a valid empty cell
            if (isValidCell(newRow, newCol) && buttons[newRow][newCol].getComponentCount() == 0) 
            {
                 // Highlight the cell
                buttons[newRow][newCol].setBackground(HIGHLIGHT_COLOR);
                // Add action listener for possible move
                addActionListenerForMove(row, col, newRow, newCol);

                // JUMP METHOD!!!! Check if jump move is possible (opponent's piece is present)
            } else if (isValidCell(newRow, newCol) && buttons[newRow][newCol].getComponentCount() != 0 &&
                       isValidCell(jumpRow, jumpCol) && buttons[jumpRow][jumpCol].getComponentCount() == 0 &&
                       ((Piece) buttons[newRow][newCol].getComponent(0)).getSide().equals(getOpponentSide(pieceColor))) 
            {
                buttons[jumpRow][jumpCol].setBackground(HIGHLIGHT_COLOR);
                // Add action listener for jump move
                addActionListenerForMove(row, col, jumpRow, jumpCol);
            }
        }
    } else {
        System.out.println("No piece in the clicked cell.");
    }
    }
    
    // Method to add action listener for a move
    private void addActionListenerForMove(int fromRow, int fromCol, int toRow, int toCol) 
    {
        // Remove previous action listeners VERY IMPORTANT!!
        ActionListener[] listeners = buttons[toRow][toCol].getActionListeners();
        for (ActionListener listener : listeners) 
        {
            buttons[toRow][toCol].removeActionListener(listener);
        }
    
        // Add new action listener for the move
        buttons[toRow][toCol].addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                //move piece from old place to new place
                Move(fromRow, fromCol, toRow, toCol);
            }
        });
    }
    
    // Reset the board colors
    private void resetBoard() 
    {
        // Reset the board colors
        for (int i = 0; i < 8; i++) 
        {
            for (int j = 0; j < 8; j++) 
            {
                if ((i + j) % 2 == 0) 
                {
                    buttons[i][j].setBackground(COLOR_1);
                    buttons[i][j].setOpaque(true);
                } else 
                {
                    buttons[i][j].setBackground(COLOR_2);
                    buttons[i][j].setOpaque(true);
                }
            }
        }
    }

    // Check if cell is within the board boundaries, must be in 8 by 8 grid, otherwise code will crash because its stupid as fuck
    private boolean isValidCell(int row, int col) 
    {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }
    //https://www.tabnine.com/code/java/methods/javax.swing.JButton/removeActionListener
    private void Move(int i, int j, int newRow, int newCol) {
    if (buttons[i][j].getComponentCount() > 0) 
    {

    Piece myPiece = (Piece) buttons[i][j].getComponent(0); // Get the source of the clicked button
        
        // Debugging
        System.out.println("Moving from cell [" + i + "," + j + "]"); //verify where piece is moved from 
        System.out.println("Button at [" + i + "][" + j + "] has " + buttons[i][j].getComponentCount() + " components."); //verify how many pieces are in the button, should always be 1

        if (buttons[newRow][newCol].getComponentCount() == 0) //veryify there are no pieces where the clicked piece is trying to move
        {
            buttons[newRow][newCol].add(myPiece); //add piece to new place
            buttons[i][j].remove(myPiece); //remove piece from old place
            buttons[i][j].repaint(); // Request an IMMEDIATE repaint of the button board otherwise it takes forever
            resetBoard();
            turnCounter++;

            //----------------------------------------------------------------------------------------------------------
            // This is for debugging all the action listeners bullshit that's happening, should ALWAYS be 64, anything else is very very very very very bad
            int totalListeners = countActionListeners();
            System.out.println("Total Action Listeners: " + totalListeners);

            System.out.println("Turn counter is " + turnCounter);
            System.out.println(myPiece.getSide() + " piece is in [" + newRow + "," + newCol + "]");
            if (buttons[newRow][newCol].getComponentCount() == 0) {
                System.out.println("No piece here");
                System.out.println("------------------");
            } else {
                Piece piece = (Piece) buttons[newRow][newCol].getComponent(0);
                System.out.println("There is a " + piece.getSide() + " piece in " + "[" + newRow + "," + newCol + "]");
                System.out.println("------------------");
            }
            //---------------------------------------------------------------------------------

            // Check if a jump move was made
            int jumpedRow = (i + newRow) / 2; // Calculate the row of the jumped opponent, there should be an  cell in the row between the old and new row which holds the opponent
            int jumpedCol = (j + newCol) / 2; // Calculate the column of the jumped opponent, same logic as the row
            if (Math.abs(i - newRow) == 2 && Math.abs(j - newCol) == 2) { //checks if the absolute difference in row and column indices between the original and destination positions is equal to 2, indicating a jump move.
                // Remove the jumped opponent from the board
                buttons[jumpedRow][jumpedCol].removeAll(); // Remove all components from the jumped cell
                buttons[jumpedRow][jumpedCol].repaint(); //call immediate repaint of board otherwise it takes forever for java to catch up
            }
        } 
        else 
        {
            System.out.println("No piece in cell [" + i + "," + j + "]");
        }
    }
    else 
    {
        System.out.println("There is no piece in the source cell [" + i + "," + j + "]" );
    }
}

    //debugging method, counts the total number of action listeners on the button grid, should be consistent at 64. 
    //should be 2 actionlisteners on each cell, anything other number is BAD BAD BAD BAD BAD BAD BAD BAD VERY VERY BAD NO
    private int countActionListeners() 
    {
        int count = 0;
        for (int i = 0; i < 8; i++) 
        {
            for (int j = 0; j < 8; j++) 
            {
                ActionListener[] listeners = buttons[i][j].getActionListeners();
                count += listeners.length;
            }
        }
        return count;
    }

    /*
    this method checks the side of pieces that are juumped. "side" represents
    the side of the current player and return the side of the opponent player. 
    If the "side" parameter is equal to "red", it returns "black" vice versa
    */
    private String getOpponentSide(String side) 
    {
        return side.equals("red") ? "black" : "red";
    }
}
        
