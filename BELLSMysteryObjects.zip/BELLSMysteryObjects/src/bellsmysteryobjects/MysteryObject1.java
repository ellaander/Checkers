/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bellsmysteryobjects;

/**
 *
 * @author becca
 */
public class MysteryObject1 {
    
//------------------------------------------------------------------------------
// PROPERTIES
//------------------------------------------------------------------------------
    
    //hat, beardlength, sarcasmlevel, mtdew, nerdlevel, darknesslevel, cardboardoverwindows, bribe
    
    private boolean hat;
    public boolean getHat()
    {
        return hat;
    }
    public void setHat(boolean hat)
    {
        this.hat = hat;
    }
    
    private int beardLength;
    public int getBeardLength()
    {
        return beardLength;
    }
    public void setBeardLength(int beardLength)
    {
        this.beardLength = beardLength;
    }
    private boolean mtDew;
    public boolean getMtDew()
    {
        return mtDew;
    }
    public void setMtDew(boolean mtDew)
    {
        this.mtDew = mtDew;
    }
    private int nerdLevel;
    public int getNerdLevel()
    {
        return nerdLevel;
    }
    public void setnerdLevel(int nerdLevel)
    {
        this.nerdLevel = nerdLevel;
    }
    private boolean cardboardoverWindows;
    public boolean getcardboardoverWindows()
    {
        return cardboardoverWindows;
    }
    public void setcardboardoverWindows()
    {
        this.cardboardoverWindows = cardboardoverWindows;
    }
    
    public MysteryObject(boolean hat,int beardLength, boolean mtDew, int nerdLevel, boolean cardboardoverWindows)
    {
        this.hat = hat;
        this.beardLength = beardLength;
        this.mtDew = mtDew;
        this.nerdLevel = nerdLevel;
        this.cardboardoverWindows = cardboardoverWindows;
    }
    
    public bribeForChocolateTruffles()
    {
    }
    
    public fillBottle()
    {
    }
    
    public feedCaveTroll()
    {
    }
    
    public turnOffLights()
    {
    }
    
    }
    
    
    
    
    
    
    
    
    public 
    
    
    
    
    
//------------------------------------------------------------------------------
// CONSTRUCTORS
//------------------------------------------------------------------------------
    
//------------------------------------------------------------------------------
// METHODS
//------------------------------------------------------------------------------
    
    
    
}
