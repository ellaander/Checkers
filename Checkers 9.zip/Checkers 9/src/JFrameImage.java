import java.awt.Graphics2D;

public class JFrameImage {

//---------------------------------------------------------------------------------------------------------------------
//  PROPERTIES
//--------------------------------------------------------------------------------------------------------------------- 


//---------------------------------------------------------------------------------------------------------------------
//  CONSTRUCTORS
//--------------------------------------------------------------------------------------------------------------------- 


//---------------------------------------------------------------------------------------------------------------------
//  METHODS
//--------------------------------------------------------------------------------------------------------------------- 

    //https://stackoverflow.com/questions/6714045/how-to-resize-jlabel-imageicon#:~:text=You%20need%20to%20use%20Java's,method%20to%20get%20the%20image.&text=This%20will%20keep%20the%20right%20aspect%20ratio.
    /* 
    private Image getScaledImage(Image srcImg, int w, int h){
        BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(srcImg, 0, 0, w, h, null);
        g2.dispose();

        return resizedImg;
    }*/




}
