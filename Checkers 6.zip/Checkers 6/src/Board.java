import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import java.util.ArrayList;

public class Board {


    // Colors for the board
    private Color COLOR_1 = new Color(250, 250, 250);
    private Color COLOR_2 = new Color(0, 0, 0);

    private Color HIGHLIGHT_COLOR = new Color(255, 255, 0);

    // Array to hold buttons
    private JButton[][] buttons = new JButton[8][8];
    private boolean[][] pressedStates = new boolean[8][8];

    // Frame and panels
    private JFrame frame = new JFrame();
    private JPanel mainPanel = new JPanel(); // Main panel to hold everything
    private JPanel buttonPanel = new JPanel();
    private JPanel leftbuttonPanel = new JPanel();
    private JPanel rightbuttonPanel = new JPanel();
    private JPanel textPanel = new JPanel();

    // Text field and button
    private JTextField text = new JTextField();
    private JButton backButton = new JButton();

    // Static variable for frame state
    public static Boolean checkJFrameState = true;

    // Array of possible moves
       //array of possible moves
       private ArrayList<JButton> possibleCells= new ArrayList<>();

    public Board() {

        try{
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
          }catch(Exception e){
           e.printStackTrace(); 
          }

        // JFrame setup
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        int screenWidth = 1000;
        int screenHeight = 900;

        // Set the frame size based on screen size
        frame.setSize(screenWidth, screenHeight);

        // Text setup
        text.setBackground(Color.BLACK);
        text.setForeground(Color.RED);
        text.setFont(new Font("SERIF", Font.BOLD, 75));
        text.setHorizontalAlignment(JLabel.CENTER);
        text.setText("CHECKERS");
        text.setOpaque(true);
        text.setEditable(false);

        // Text panel setup
        textPanel.setLayout(new BorderLayout());
        textPanel.add(text);

        // Back button setup
        backButton.setText("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                GUI.frame.setState(Frame.NORMAL);
            }
        });

        // Add components to frame
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(textPanel, BorderLayout.NORTH);

        // Button panel setup
        buttonPanel.setLayout(new GridLayout(8, 8));
        buttonPanel.setPreferredSize(new Dimension(550, 550));

        rightbuttonPanel.setLayout(new GridLayout(4,2));
        rightbuttonPanel.setPreferredSize(new Dimension(75,300));

        leftbuttonPanel.setLayout(new GridLayout(4,2));
        leftbuttonPanel.setPreferredSize(new Dimension(75,300));

        mainPanel.add(rightbuttonPanel, BorderLayout.CENTER);
        mainPanel.add(leftbuttonPanel,BorderLayout.CENTER);

        JPanel centerPanel = new JPanel(new GridBagLayout()); // Panel to center the buttonPanel
        centerPanel.add(buttonPanel);

        // Add centerPanel with buttonPanel to main panel, with empty borders for space
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Initialize buttons and add to panel
        initializeButtons();
        resetBoard();

        // Add main panel to frame
        frame.add(mainPanel);
        frame.setVisible(true);

        mainPanel.add(backButton, BorderLayout.SOUTH);
        frame.setResizable(false);
    }


    // Initialize buttons and add to panel
    private void initializeButtons() {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            final int row = i; // Final variables for action listener
            final int col = j;
            buttons[i][j] = new JButton();
            buttons[i][j].setFocusable(false);
            buttons[i][j].setOpaque(true);
            buttons[i][j].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                    try {
                        highlightPossibleMoves(row, col);
                        Move(row, col);
                    }catch (Exception k){}
                }
            });
                buttonPanel.add(buttons[i][j]);
        }
    }
        // Add red pieces to board
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 == 0) {
                    Piece piece = new Piece("red");
                    buttons[i][j].setLayout(new FlowLayout(FlowLayout.CENTER));
                    buttons[i][j].add(piece);
                }
            }
        }
        // Add black pieces to board
        for (int i = 6; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 == 0) {
                    Piece piece = new Piece("black");
                    buttons[i][j].setLayout(new FlowLayout(FlowLayout.CENTER));
                    buttons[i][j].add(piece);
                }
            }
        }
    }

    // Highlight possible moves buttons
    /**
     * @param row
     * @param col
     */
    private void highlightPossibleMoves(int row, int col) {
        // Reset the board colors
        resetBoard();

        int[] dx; // Diagonal directions (right-down, right-up, left-down, left-up)
        int[] dy;

        String pieceColor = ((Piece) buttons[row][col].getComponent(0)).getSide();

        if (pieceColor.equals("red")) {
            dx = new int[]{1, 1};
            dy = new int[]{1, -1};
        } else {
            dx = new int[]{-1, -1};
            dy = new int[]{-1, 1};
        }

        for (int i = 0; i < 2; i++) { // Iterate over all diagonal directions
            int newRow = row + dx[i];
            int newCol = col + dy[i];

            if (isValidCell(newRow, newCol)) {
                buttons[newRow][newCol].setBackground(HIGHLIGHT_COLOR);
                pressedStates[newRow][newCol] = true;
                possibleCells.add(buttons[newRow][newCol]);
                disableBoard();
            }
        }

        pressedStates[row][col] = true;
    }

    // Reset the board colors
    private void resetBoard() {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if ((i + j) % 2 == 0) {
                    buttons[i][j].setBackground(COLOR_1);
                    buttons[i][j].setOpaque(true);
                } else {
                    buttons[i][j].setBackground(COLOR_2);
                    buttons[i][j].setOpaque(true);
                }
                pressedStates[i][j] = false;
            }
        }
    }

    // Check if cell is within the board boundaries
    private boolean isValidCell(int row, int col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }

    private void Move(int i, int j) {
        Piece myPiece= (Piece) buttons[i][j].getComponent(0);
        if (possibleCells.size()>0) {
            for (int k = 0; k < 2; k++) {
                final int p = k;
                possibleCells.get(k).addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        possibleCells.get(p).add(myPiece);
                        buttons[i][j].remove(myPiece);
                    }
                });
            }
        }
        enableBoard();
    }
     //Disable buttons except those highlighted
     private void disableBoard(){

        for (int i=0;i<8;i++){
            for (int j=0;j<8;j++){
                buttons[i][j].setEnabled(false);
                for (int a=0;a<possibleCells.size();a++){
                    possibleCells.get(a).setEnabled(true);
                }

            }
        }
    }
      //Enable all buttons
      private void enableBoard(){
        for (int i=0;i<8;i++){
            for (int j=0;j<8;j++){
                    buttons[i][j].setEnabled(true);
            }
        }
    }
}

