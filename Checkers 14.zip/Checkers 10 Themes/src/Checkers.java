//main class, calls GUI to start

public class Checkers 
{
   
    public static void main(String[] args) throws Exception 
    {
        new GUI();
    }
}
