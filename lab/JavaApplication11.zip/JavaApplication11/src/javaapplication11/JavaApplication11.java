/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

import static com.sun.javafx.scene.control.skin.Utils.getResource;
import java.io.File;
import java.net.URL;
import javax.swing.ImageIcon;

/**
 *
 * @author dlampl
 */
public class JavaApplication11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { 
        
        File asdf = new File("");
        ImageIcon asdf1 = new ImageIcon("settingsCat.jpeg");
        
        System.out.println(asdf1.getImage().toString());
        
        File asdf2 = new File("img/niblet2.0.png");
        System.out.println(asdf2.getAbsolutePath());
    }
    
}
