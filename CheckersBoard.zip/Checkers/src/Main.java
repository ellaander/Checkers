import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public Color COLOR_1 = new Color(123, 123, 123);
    public Color COLOR_2 = new Color(0, 0, 0);
    public static JButton[][] buttons = new JButton[8][8];
    public static JFrame frame = new JFrame();
    public static JPanel buttonPanel = new JPanel();

    public static JTextField text = new JTextField();

    public static JPanel textPanel = new JPanel();



    public static void main(String[] args) {

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1500, 1000);
        frame.setResizable(false);
        buttonPanel.setLayout(new GridLayout(8, 8));
        buttonPanel.setSize(800, 800);
        text.setBackground(Color.BLACK);
        text.setForeground(Color.RED);
        text.setFont(new Font("SERIF", Font.BOLD, 75));
        text.setHorizontalAlignment(JLabel.CENTER);
        text.setText("CHECKERS");
        text.setOpaque(true);
        text.setEditable(false);
        textPanel.setLayout(new BorderLayout());
        textPanel.setBounds(0, 0, 1500, 100);
        textPanel.add(text);
        frame.add(textPanel, BorderLayout.NORTH);


        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                buttons[i][j] = new JButton();
                buttons[i][j].setSize(10, 10);
                buttons[i][j].setFocusable(false);
                buttonPanel.add(buttons[i][j]);
            }
        }

        resetBoard();



        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                int finalJ = j;
                int finalI = i;

                if (buttons[i][j].getBackground()==Color.BLACK) {

                    buttons[i][j].addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            resetBoard();
                            try {
                                buttons[finalI - 1][finalJ - 1].setBackground(Color.YELLOW);
                            } catch (Exception p) {
                            }
                            try {
                                buttons[finalI - 1][finalJ + 1].setBackground(Color.YELLOW);
                            } catch (Exception p) {
                            }
                            try {
                                buttons[finalI + 1][finalJ + 1].setBackground(Color.YELLOW);
                            } catch (Exception p) {
                            }
                            try {
                                buttons[finalI + 1][finalJ - 1].setBackground(Color.YELLOW);
                            } catch (Exception p) {
                            }
                        }
                    });
                }

            }
        }



        frame.add(buttonPanel);
        frame.setVisible(true);
    }


    private static void resetBoard(){
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if((i%2)==0){
                    if((j%2)==0){
                        buttons[i][j].setBackground(Color.BLACK);
                    }
                    else{buttons[i][j].setBackground(Color.WHITE);}
                }
                else{
                    if((j%2)==0){
                        buttons[i][j].setBackground(Color.WHITE);
                    }
                    else{buttons[i][j].setBackground(Color.BLACK);}
                }
            }
        }
    }
}


