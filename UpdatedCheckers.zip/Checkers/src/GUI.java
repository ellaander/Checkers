import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class GUI implements ActionListener
{
    static JFrame frame;
    private JPanel mainPanel;
    private JPanel howToPlayPanel;
    private JPanel settingsPanel;
    private CardLayout cardLayout;

    ImageIcon howToPlayImage = new ImageIcon("howtoPlayCat.jpeg");
    ImageIcon settingsImage = new ImageIcon("settingsCat.jpeg");

    public GUI() 
    {
        frame = new JFrame();

        //mainPanel 
        JButton homeComponent2 = new JButton("Home Component 2");
        homeComponent2.setBounds(200, 300, 400, 150);
        homeComponent2.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {

                frame.setState(Frame.ICONIFIED);
                new Board();

            }
        });

        JButton homeComponent4 = new JButton("Home Component 4");
        homeComponent4.setBounds(200, 550, 175, 175);
        homeComponent4.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                cardLayout.show(frame.getContentPane(), "HowToPlay");
            }
        });

        JButton homeComponent3 = new JButton("Home Component 3");
        homeComponent3.setBounds((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - 600, 300, 400, 150);
        homeComponent3.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                cardLayout.show(frame.getContentPane(), "Settings");
            }
        });

        mainPanel = new JPanel(null);
        mainPanel.setPreferredSize(Toolkit.getDefaultToolkit().getScreenSize());
        mainPanel.add(homeComponent4);
        mainPanel.add(homeComponent3);
        mainPanel.add(homeComponent2);

        //howToPlayPanel 
        JButton backButton_HowToPlay = new JButton("Back");
        backButton_HowToPlay.setBounds(200, 550, 175, 175);
        backButton_HowToPlay.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                cardLayout.show(frame.getContentPane(), "Main");
            }
        });

        howToPlayPanel = new JPanel(null);
        JLabel image_how_to_play_Label = new JLabel(howToPlayImage);
        image_how_to_play_Label.setBounds(50, 50, howToPlayImage.getIconWidth(), howToPlayImage.getIconHeight());
        howToPlayPanel.add(image_how_to_play_Label);
        howToPlayPanel.add(backButton_HowToPlay);

        //settingsPanel
        JButton backButton_Settings = new JButton("Back");
        backButton_Settings.setBounds(200, 550, 175, 175);
        backButton_Settings.addActionListener(new ActionListener() 
        {
            @Override
            public void actionPerformed(ActionEvent e) 
            {
                cardLayout.show(frame.getContentPane(), "Main");
            }
        });

        settingsPanel = new JPanel(null);
        JLabel image_settings_Label = new JLabel(settingsImage);
        image_settings_Label.setBounds(50, 50, settingsImage.getIconWidth(), settingsImage.getIconHeight() - 200);
        settingsPanel.add(image_settings_Label);
        settingsPanel.add(backButton_Settings);

        cardLayout = new CardLayout();
        frame.setLayout(cardLayout);
        frame.add(mainPanel, "Main");
        frame.add(howToPlayPanel, "HowToPlay");
        frame.add(settingsPanel, "Settings");


        cardLayout.show(frame.getContentPane(), "Main");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Checkers");
        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
    }
    public static void main(String[] args) 
    {
        SwingUtilities.invokeLater(() -> new GUI());
    }
}
